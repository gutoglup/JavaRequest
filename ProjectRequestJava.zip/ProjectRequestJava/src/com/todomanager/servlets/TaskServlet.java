package com.todomanager.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.todomanager.domain.Task;

/**
 * Servlet implementation class TaskServlet
 */
@WebServlet("/tasks/*")
public class TaskServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static List<Task> listOfTasks;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TaskServlet() {
		super();
		this.listOfTasks = new ArrayList<Task>();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		String pathInfo = request.getPathInfo();
		if (pathInfo == null || pathInfo.equals("/")) {
			doGetAll(request, response);
		} else {
			String [] splits = pathInfo.split("/");
			String taskId = splits[1];
			doGetById(request, response, taskId);
		}
	}

	protected void doGetById(HttpServletRequest request, HttpServletResponse response, String taskId) throws ServletException, IOException {
		Task task = findTaskById(taskId);
		if (task == null) {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			response.getWriter().write("");
		} else {
			Gson gson = new Gson();

			String json = gson.toJson(task);
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().write(json);
		}

	}

	protected void doGetAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Gson gson = new Gson();

		String json = gson.toJson(listOfTasks);
		response.getWriter().write(json);
	}

	private Task findTaskById(String taskId) {
		Optional<Task> result = this.listOfTasks.stream().filter(task -> task.getId().equals(taskId)).findFirst();
		return result.isPresent() ? result.get() : null;
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Gson gson = new Gson();
		Task task = gson.fromJson(request.getReader(), Task.class);
		this.listOfTasks.add(task);

		response.setStatus(HttpServletResponse.SC_CREATED);
		response.getWriter().write(gson.toJson(task));
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] splits = request.getPathInfo().split("/");
		if (splits.length != 3) {
			String taskId = splits[1];
			Task task = this.findTaskById(taskId);
			if (task == null) {
				response.setStatus(HttpServletResponse.SC_NOT_FOUND);
				response.getWriter().write("");
				return;
			} else {

				Gson gson = new Gson();
				Task taskUpdated = gson.fromJson(request.getReader(), Task.class);
				int taskIndex = this.listOfTasks.indexOf(task);
				this.listOfTasks.remove(task);
				this.listOfTasks.add(taskIndex, taskUpdated);

				response.setStatus(HttpServletResponse.SC_OK);
				response.getWriter().write("");
			}
		} else {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().write("");
		}
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] splits = request.getPathInfo().split("/");
		if (splits.length != 3) {
			String taskId = splits[1];
			Task task = this.findTaskById(taskId);
			if (task == null) {
				response.setStatus(HttpServletResponse.SC_NOT_FOUND);
				response.getWriter().write("");
				return;
			} else {
				this.listOfTasks.remove(task);
				response.setStatus(HttpServletResponse.SC_OK);
				response.getWriter().write("");
			}
		} else {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.getWriter().write("");
		}
	}

}
